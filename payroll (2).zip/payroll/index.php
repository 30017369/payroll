<?php
 include 'include/dbh.php';
?>
<style>
.header {
  padding: 60px;
  text-align: center;
  background: #1abc9c;
  color: white;
  font-size: 30px;
}
 footer {
  text-align: center;
  padding: 20px;
  background-color: black;
  color: white;
   position: fixed;
  bottom: 0;
  width: 100%;
}
</style>
<html>
 <head>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payroll</title> 
 </head>
 <body>
     <div class="header">
         
     <?php echo '<h1>PAYROLL</h1>'; ?> 

  <a href="admin/admin.php">I'm an Admin</label> <br><br>
  <a href="employee.php">I'm an Employee</label>
 
</div>
  <br><br>
</form>

</body>	
	<footer class="Copyright">
	Copyright &copy;2021 | GG PRINTERS, All Rights Reserved
	<label>Developer: JATIN & FINTU</a></label>
</footer>
</html>