<style>
	.menu{
		color: white;
		background-color: black;
		padding: 10px;
		font-size: 1.3em;
		
	}
	.menu:hover{
		color: blue;
		background-color: white;
		padding: 10px;
		box-shadow: 5px 4px 5px 1px;
	}
</style>
<ul style="list-style:none;display:inline-block">
	<li style="float:left">&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php" class="menu">Add Employee</a>&nbsp;&nbsp;&nbsp;&nbsp;</li>
    <li style="float:left">&nbsp;&nbsp;&nbsp;&nbsp;<a href="getattendance.php" class="menu">Get Attendance</a>&nbsp;&nbsp;&nbsp;&nbsp;</li>
    <li style="float:left">&nbsp;&nbsp;&nbsp;&nbsp;<a href="printreport.php" class="menu">Print Report</a>&nbsp;&nbsp;&nbsp;&nbsp;</li>
    <li style="float:left">&nbsp;&nbsp;&nbsp;&nbsp;<a href="viewmember.php" class="menu">View Employees</a>&nbsp;&nbsp;&nbsp;&nbsp;</li>
    <br>
    <br>
    <br>
    <li style="float:left">&nbsp;&nbsp;&nbsp;&nbsp;<a href="admin.php" class="menu">Admin Page</a>&nbsp;&nbsp;&nbsp;&nbsp;</li>
</ul>